"""Executa uma compilação e captura a saída dos experimentos.

Cada execução parte de uma reinicialização: na Zbook, o script abre a porta
serial, grava a imagem com `west flash` (que reinicia a placa) e lê o console
até a linha `#END`; no QEMU, roda o alvo `run` da compilação.

Uso:
    python scripts/capture.py BUILD_DIR SAIDA.txt [--target zbook|qemu]
                              [--port /dev/ttyACM0] [--timeout 1800]
"""

import argparse
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

END = "#END"


def west_flash_cmd(build_dir: Path) -> list[str]:
    """`west flash`, com o OpenOCD de OPENOCD/OPENOCD_SCRIPTS quando definidos."""
    cmd = ["west", "flash", "-d", str(build_dir)]
    if os.environ.get("OPENOCD"):
        cmd += ["--openocd", os.environ["OPENOCD"]]
    if os.environ.get("OPENOCD_SCRIPTS"):
        cmd += ["--openocd-search", os.environ["OPENOCD_SCRIPTS"]]
    return cmd


def capture_zbook(build_dir: Path, port: str, baud: int, timeout: float) -> list[str]:
    import serial

    lines: list[str] = []
    done = threading.Event()

    with serial.Serial(port, baud, timeout=0.5) as ser:
        ser.reset_input_buffer()

        def reader() -> None:
            buf = b""
            while not done.is_set():
                buf += ser.read(4096)
                *complete, buf = buf.split(b"\n")
                for raw in complete:
                    line = raw.decode(errors="replace").rstrip("\r")
                    lines.append(line)
                    if line.startswith(END):
                        done.set()

        t = threading.Thread(target=reader, daemon=True)
        t.start()
        flash = subprocess.run(west_flash_cmd(build_dir), capture_output=True, text=True)
        if flash.returncode != 0:
            done.set()
            sys.stderr.write(flash.stdout + flash.stderr)
            raise RuntimeError("falha na gravação")
        if not done.wait(timeout):
            done.set()
            raise TimeoutError(f"sem {END} após {timeout} s")
        t.join()
    return lines


def capture_qemu(build_dir: Path, timeout: float) -> list[str]:
    lines: list[str] = []
    # Grupo de processos próprio: o QEMU é neto do west e precisa ser
    # encerrado junto, ou a execução seguinte encontra o arquivo de PID travado.
    proc = subprocess.Popen(["west", "build", "-d", str(build_dir), "-t", "run"],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                            start_new_session=True)
    deadline = time.monotonic() + timeout
    try:
        assert proc.stdout is not None
        for line in proc.stdout:
            line = line.rstrip("\n")
            lines.append(line)
            if line.startswith(END):
                break
            if time.monotonic() > deadline:
                raise TimeoutError(f"sem {END} após {timeout} s")
    finally:
        os.killpg(proc.pid, signal.SIGTERM)
        proc.wait()
    return lines


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("build_dir", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--target", choices=["zbook", "qemu"], default="zbook")
    ap.add_argument("--port", default="/dev/ttyACM0")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--timeout", type=float, default=1800)
    args = ap.parse_args()

    if args.target == "zbook":
        lines = capture_zbook(args.build_dir, args.port, args.baud, args.timeout)
    else:
        lines = capture_qemu(args.build_dir, args.timeout)

    if not any(line.startswith(END) for line in lines):
        sys.stderr.write("\n".join(lines[-20:]) + "\n")
        raise RuntimeError(f"execução terminou sem {END}")

    # Mantém apenas o bloco de resultados, de #BOOT a #END. Restos do
    # firmware anterior podem estar no buffer da serial, inclusive na mesma
    # linha do #BOOT, e a aplicação pode imprimir algo depois do #END.
    start = max((i for i, l in enumerate(lines) if "#BOOT" in l), default=0)
    lines[start] = lines[start][lines[start].find("#BOOT"):]
    end = next(i for i, l in enumerate(lines) if l.startswith(END))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines[start:end + 1]) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
