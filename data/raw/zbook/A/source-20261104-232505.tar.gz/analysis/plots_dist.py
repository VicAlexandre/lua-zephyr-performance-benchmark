"""Gráficos de distribuição (boxplot e CCDF) a partir dos dados brutos.

Uso:
    python analysis/plots_dist.py [--raw data/raw/zbook] [--out data/results/zbook/figuras]
"""

import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from analyze import load_config, metrics  # noqa: E402
from plots import COLORS, DEADLINE_MS, LABELS, PT, num, plt  # noqa: E402
from matplotlib.ticker import FuncFormatter, NullFormatter  # noqa: E402

B_MODELS = ("BASE", "MT", "MC")
C_MODELS = ("MC", "MTEQ", "MTSPLIT")


def pooled(cfg_dir: Path, metric: str) -> np.ndarray:
    runs = load_config(cfg_dir)
    return np.concatenate([metrics(r)[metric] for r in runs]) / 1000 if runs else np.array([])


def box(ax, data: list[np.ndarray], pos: list[float], color: str, width: float) -> None:
    """Caixa nos quartis, bigodes de p1 a p99 e marcador no p99,9."""
    for x, d in zip(pos, data):
        if d.size == 0:
            continue
        p1, q1, med, q3, p99, p999 = np.quantile(d, [0.01, 0.25, 0.5, 0.75, 0.99, 0.999],
                                                 method="inverted_cdf")
        ax.add_patch(plt.Rectangle((x - width / 2, q1), width, q3 - q1, fc=color, ec=color,
                                   alpha=0.35))
        ax.plot([x - width / 2, x + width / 2], [med, med], color=color, lw=1.6)
        ax.plot([x, x], [p1, q1], color=color, lw=0.9)
        ax.plot([x, x], [q3, p99], color=color, lw=0.9)
        for y in (p1, p99):
            ax.plot([x - width / 4, x + width / 4], [y, y], color=color, lw=0.9)
        ax.plot(x, p999, "_", color=color, ms=9, mew=1.6)
        ax.plot(x, p999, ".", color=color, ms=4)


def log_axis(ax, ticks) -> None:
    ax.set_yscale("log")
    ax.set_yticks(ticks)
    ax.yaxis.set_major_formatter(PT)
    ax.yaxis.set_minor_formatter(NullFormatter())


def legend_models(ax, models, extra=True, **kw) -> None:
    hs = [plt.Rectangle((0, 0), 1, 1, fc=COLORS[m], alpha=0.5) for m in models]
    ls = [LABELS[m] for m in models]
    if extra:
        hs.append(plt.Line2D([], [], color="black", marker="_", ls="", ms=9, mew=1.6))
        ls.append("p99,9")
    ax.legend(hs, ls, **kw)


def fig_b_box(raw: Path, out: Path) -> None:
    payloads = [1, 16, 64, 256, 1024]
    fig, ax = plt.subplots()
    w = 0.25
    for j, m in enumerate(B_MODELS):
        data = [pooled(raw / "B" / f"B_{m}_p{p}", "latency") for p in payloads]
        box(ax, data, [i + (j - 1) * w for i in range(len(payloads))], COLORS[m], w * 0.8)
    ax.set_xticks(range(len(payloads)), [str(p) for p in payloads])
    ax.set_xlim(-0.5, len(payloads) - 0.5)
    log_axis(ax, [0.1, 0.2, 0.5, 1, 2, 5])
    ax.set_ylim(0.15, 6)
    ax.set_xlabel("payload (bytes)")
    ax.set_ylabel("latência (ms)")
    ax.grid(axis="x", visible=False)
    legend_models(ax, B_MODELS, loc="upper center", ncol=4, bbox_to_anchor=(0.5, 1.12))
    fig.savefig(out / "b_box.pdf")
    plt.close(fig)


def ccdf(ax, d: np.ndarray, color: str, label: str) -> None:
    x = np.sort(d)
    y = 1 - np.arange(len(x)) / len(x)
    ax.step(x, y, where="post", color=color, label=label, lw=1.3)


def ccdf_axes(ax) -> None:
    ax.set_yscale("log")
    ax.set_ylim(5e-5, 1.2)
    ax.set_yticks([1, 1e-1, 1e-2, 1e-3, 1e-4], ["1", "0,1", "0,01", "0,001", "0,0001"])
    ax.yaxis.set_minor_formatter(NullFormatter())
    for q, lab in ((1e-2, "p99"), (1e-3, "p99,9")):
        ax.axhline(q, color="#999999", lw=0.7, ls=":")
        ax.text(ax.get_xlim()[1], q * 1.15, lab, ha="right", fontsize=8, color="#666666")


def fig_b_ccdf(raw: Path, out: Path, payload: int = 64) -> None:
    fig, ax = plt.subplots()
    for m in B_MODELS:
        ccdf(ax, pooled(raw / "B" / f"B_{m}_p{payload}", "latency"), COLORS[m], LABELS[m])
    ax.set_xlim(0, 4.5)
    ax.xaxis.set_major_formatter(PT)
    ccdf_axes(ax)
    ax.set_xlabel(f"latência (ms), payload de {payload} bytes")
    ax.set_ylabel("fração das ativações acima de $x$")
    ax.legend(loc="upper right", bbox_to_anchor=(1, 0.9))
    fig.savefig(out / "b_ccdf.pdf")
    plt.close(fig)


def fig_b_hist(raw: Path, out: Path, payload: int = 64) -> None:
    """Histograma no estilo do cyclictest: contagem em escala log, caixas de 10 us."""
    data = {m: pooled(raw / "B" / f"B_{m}_p{payload}", "latency") for m in B_MODELS}
    top = max(d.max() for d in data.values())
    bins = np.arange(0, top + 0.01, 0.01)
    fig, axes = plt.subplots(3, 1, figsize=(6.3, 7.2), sharex=True, sharey=True)
    for ax, m in zip(axes, B_MODELS):
        d = data[m]
        ax.hist(d, bins=bins, color=COLORS[m], histtype="stepfilled", ec=COLORS[m], lw=0.8)
        for q, ls in ((0.5, "-"), (0.99, "--"), (0.999, ":")):
            ax.axvline(np.quantile(d, q, method="inverted_cdf"), color="black", lw=0.8, ls=ls)
        ax.set_yscale("log")
        ax.set_ylim(0.7, 2e4)
        ax.set_axisbelow(True)
        ax.set_yticks([1, 10, 100, 1000, 10000], ["1", "10", "100", "1.000", "10.000"])
        ax.yaxis.set_minor_formatter(NullFormatter())
        ax.text(0.99, 0.85, LABELS[m], transform=ax.transAxes, ha="right", fontsize=10)
    axes[1].set_ylabel("número de ativações")
    axes[-1].set_xlabel(f"latência (ms), payload de {payload} bytes")
    axes[-1].set_xlim(0, top * 1.03)
    axes[-1].xaxis.set_major_formatter(PT)
    hs = [plt.Line2D([], [], color="black", lw=0.8, ls=ls) for ls in ("-", "--", ":")]
    axes[0].legend(hs, ["mediana", "p99", "p99,9"], loc="upper center", ncol=3,
                   bbox_to_anchor=(0.5, 1.2))
    fig.savefig(out / "b_hist.pdf")
    plt.close(fig)


def fig_c_box(raw: Path, out: Path) -> None:
    slices = [100, 300, 1_000, 3_000, 10_000, 30_000, 50_000, 100_000]
    fig, ax = plt.subplots()
    w = 0.25
    for j, m in enumerate(C_MODELS):
        data = [pooled(raw / "C" / f"C_{m}_s{s}", "response") for s in slices]
        box(ax, data, [i + (j - 1) * w for i in range(len(slices))], COLORS[m], w * 0.8)
    ax.axhline(DEADLINE_MS, color="#c0392b", lw=1, ls="--")
    ax.text(-0.4, DEADLINE_MS * 1.12, f"deadline ({DEADLINE_MS} ms)", color="#c0392b", fontsize=9)
    ax.set_xticks(range(len(slices)), [num(s / 1000) for s in slices])
    ax.set_xlim(-0.5, len(slices) - 0.5)
    log_axis(ax, [0.5, 1, 3, 10, 30, 100, 300])
    ax.set_ylim(0.4, 400)
    ax.set_xlabel("trecho sem ceder $S$ (ms)")
    ax.set_ylabel("tempo de resposta (ms)")
    ax.grid(axis="x", visible=False)
    legend_models(ax, C_MODELS, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.2))
    fig.savefig(out / "c_box.pdf")
    plt.close(fig)


def fig_c_ccdf(raw: Path, out: Path) -> None:
    slices = [1_000, 10_000, 50_000]
    fig, axes = plt.subplots(1, 3, figsize=(6.4, 2.8), sharey=True)
    for ax, s in zip(axes, slices):
        for m in C_MODELS:
            ccdf(ax, pooled(raw / "C" / f"C_{m}_s{s}", "response"), COLORS[m], LABELS[m])
        ax.set_xscale("log")
        ax.set_xlim(0.4, 150)
        ax.set_xticks([1, 10, 100], ["1", "10", "100"])
        ax.xaxis.set_minor_formatter(NullFormatter())
        ax.axvline(DEADLINE_MS, color="#c0392b", lw=1, ls="--")
        ax.set_title(f"$S$ = {num(s / 1000)} ms", fontsize=10)
        ccdf_axes(ax)
    axes[1].set_xlabel("tempo de resposta (ms)")
    axes[0].set_ylabel("fração acima de $x$")
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.06))
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    fig.savefig(out / "c_ccdf.pdf")
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--raw", type=Path, default=Path("data/raw/zbook"))
    ap.add_argument("--out", type=Path, default=Path("data/results/zbook/figuras"))
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    for fig in (fig_b_box, fig_b_ccdf, fig_b_hist, fig_c_box, fig_c_ccdf):
        fig(args.raw, args.out)
        print(f"{fig.__name__} ok")


if __name__ == "__main__":
    main()
