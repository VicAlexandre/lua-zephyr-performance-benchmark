"""Gráficos dos resultados a partir dos CSVs de data/results.

Uso:
    python analysis/plots.py [--results data/results/zbook] [--out figuras]

Gera um PDF por figura, em fonte Times (STIX) e com vírgula decimal, para
inclusão direta no texto.
"""

import argparse
import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import FuncFormatter, LogLocator, NullFormatter  # noqa: E402

RAM_TOTAL_KB = 520
DEADLINE_MS = 100

COLORS = {"BASE": "#7f7f7f", "MT": "#1f5fa8", "MTEQ": "#1f5fa8", "MTSPLIT": "#5aa05a",
          "MC": "#d07a1f"}
LABELS = {"BASE": "C puro", "MT": "MT", "MC": "MC", "MTEQ": "MT, prioridades iguais",
          "MTSPLIT": "MT, prioridades distintas"}
MARKERS = {"BASE": "s", "MT": "o", "MTEQ": "o", "MTSPLIT": "^", "MC": "D"}

plt.rcParams.update({
    "font.family": "STIXGeneral",
    "mathtext.fontset": "stix",
    "font.size": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.color": "#dddddd",
    "grid.linewidth": 0.6,
    "legend.frameon": False,
    "figure.figsize": (6.0, 3.4),
    "savefig.bbox": "tight",
})


def num(v: float) -> str:
    """Número em padrão pt-BR, sem zeros à direita."""
    s = f"{v:,.2f}".rstrip("0").rstrip(".")
    return s.replace(",", "\0").replace(".", ",").replace("\0", ".")


PT = FuncFormatter(lambda v, _: num(v))


def read(path: Path) -> list[dict]:
    with path.open() as f:
        return list(csv.DictReader(f))


def fig_a_ram(res: Path, out: Path) -> None:
    rows = read(res / "A_footprint.csv")
    fits = {r["model"]: r for r in read(res / "A_fit.csv")}
    ref_kb = next((int(r["ram_reserved"]) - int(r["ram_lua"])) / 1024
                  for r in rows if r["fits"] == "1")

    fig, ax = plt.subplots()
    for model in ("MT", "MC"):
        pts = sorted((int(r["n"]), int(r["ram_reserved"]) / 1024) for r in rows
                     if r["model"] == model and r["fits"] == "1" and r["n"].isdigit())
        n, kb = zip(*pts)
        ax.plot(n, kb, MARKERS[model], color=COLORS[model], label=LABELS[model])
        f = fits[model]
        a, b = float(f["a_bytes"]) / 1024, float(f["b_bytes_per_task"]) / 1024
        xs = [1, min(31, (RAM_TOTAL_KB * 1.1 - ref_kb - a) / b)]
        ax.plot(xs, [ref_kb + a + b * x for x in xs], "-", lw=1, color=COLORS[model], alpha=0.6)
        ax.annotate(f"{num(round(b, 1))} KB/tarefa", (xs[-1], ref_kb + a + b * xs[-1]),
                    xytext=(-6, 4), textcoords="offset points", ha="right", color=COLORS[model])
    # Configurações que não couberam: marcadas na altura prevista pelo ajuste.
    for r in rows:
        if r["fits"] != "1" and r["n"].isdigit():
            ax.plot(int(r["n"]), RAM_TOTAL_KB, "x", color=COLORS[r["model"]], ms=8, mew=2)
            ax.annotate("não coube", (int(r["n"]), RAM_TOTAL_KB), xytext=(-6, -14),
                        textcoords="offset points", ha="right", color=COLORS[r["model"]])
    ax.axhline(RAM_TOTAL_KB, color="black", lw=0.8, ls="--")
    ax.text(1, RAM_TOTAL_KB + 8, f"RAM total ({RAM_TOTAL_KB} KB)", fontsize=9)
    ax.set_xlabel("número de tarefas $N$")
    ax.set_ylabel("RAM reservada (KB)")
    ax.set_xticks([1, 2, 4, 8, 16, 31])
    ax.set_ylim(0, RAM_TOTAL_KB * 1.12)
    ax.yaxis.set_major_formatter(PT)
    ax.legend(loc="center right")
    fig.savefig(out / "a_ram.pdf")
    plt.close(fig)


def fig_b_latency(res: Path, out: Path) -> None:
    rows = [r for r in read(res / "B_summary.csv") if r["metric"] == "latency"]
    payloads = sorted({int(r["config"].rsplit("_p", 1)[1]) for r in rows})
    fig, axes = plt.subplots(1, 2, figsize=(6.0, 3.0), sharex=True)
    for ax, stat, title in ((axes[0], "median", "mediana"), (axes[1], "p999", "p99,9")):
        for model in ("BASE", "MT", "MC"):
            by_p = {int(r["config"].rsplit("_p", 1)[1]): r for r in rows
                    if r["config"].split("_")[1] == model}
            ys = [float(by_p[p][stat]) / 1000 for p in payloads]
            lo = [y - float(by_p[p][f"{stat}_lo"]) / 1000 for p, y in zip(payloads, ys)]
            hi = [float(by_p[p][f"{stat}_hi"]) / 1000 - y for p, y in zip(payloads, ys)]
            ax.errorbar(range(len(payloads)), ys, yerr=[lo, hi], marker=MARKERS[model],
                        color=COLORS[model], label=LABELS[model], capsize=2, lw=1)
        ax.set_title(title, fontsize=10)
        ax.set_xticks(range(len(payloads)), [str(p) for p in payloads])
        ax.set_xlabel("payload (bytes)")
        ax.set_ylim(bottom=0)
        ax.yaxis.set_major_formatter(PT)
    axes[0].set_ylabel("latência (ms)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.04))
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    fig.savefig(out / "b_latencia.pdf")
    plt.close(fig)


def _c_rows(res: Path) -> dict[str, list[tuple[float, dict]]]:
    series: dict[str, list[tuple[float, dict]]] = {}
    for r in read(res / "C_viability.csv"):
        _, model, s = r["config"].split("_")
        series.setdefault(model, []).append((int(s[1:]) / 1000, r))
    return {m: sorted(v, key=lambda t: t[0]) for m, v in series.items()}


def _log_ms_axis(ax) -> None:
    ax.set_xscale("log")
    ax.xaxis.set_major_formatter(PT)
    ax.xaxis.set_minor_formatter(NullFormatter())


def fig_c_response(res: Path, out: Path) -> None:
    series = _c_rows(res)
    fig, ax = plt.subplots()
    for model in ("MC", "MTEQ", "MTSPLIT"):
        s, rows = zip(*series[model])
        ys = [float(r["p99_us"]) / 1000 for r in rows]
        hi = [float(r["p99_hi_us"]) / 1000 - y for r, y in zip(rows, ys)]
        ax.errorbar(s, ys, yerr=[[0] * len(ys), hi], marker=MARKERS[model], color=COLORS[model],
                    label=LABELS[model], capsize=2, lw=1)
        for x, r in zip(s, rows):
            if r["viable_p99"] == "0":
                ax.plot(x, float(r["p99_us"]) / 1000, "o", ms=12, mfc="none", mec="#c0392b", mew=1.5)
    ax.axhline(DEADLINE_MS, color="#c0392b", lw=1, ls="--")
    ax.text(0.09, DEADLINE_MS + 3, f"deadline ({DEADLINE_MS} ms)", color="#c0392b", fontsize=9)
    _log_ms_axis(ax)
    ax.set_xticks([0.1, 0.3, 1, 3, 10, 30, 100])
    ax.set_xlabel("trecho sem ceder $S$ (ms)")
    ax.set_ylabel("p99 do tempo de resposta (ms)")
    top = max(float(r["p99_hi_us"]) for v in series.values() for _, r in v) / 1000
    ax.set_ylim(0, max(115, top * 1.05))
    ax.legend(loc="upper left", bbox_to_anchor=(0, 0.88))
    fig.savefig(out / "c_resposta.pdf")
    plt.close(fig)


def fig_c_mc_band(res: Path, out: Path) -> None:
    rows = [r for r in read(res / "C_summary.csv")
            if r["metric"] == "latency" and r["config"].startswith("C_MC_")]
    pts = sorted((int(r["config"].rsplit("_s", 1)[1]) / 1000, r) for r in rows)
    s = [p[0] for p in pts]
    fig, ax = plt.subplots()
    ax.fill_between([0.08, 120], [0.08, 120], [0.16, 240], color=COLORS["MC"], alpha=0.12,
                    label="faixa prevista ($S$ a $2S$)")
    ax.plot([0.08, 120], [0.08, 120], color=COLORS["MC"], lw=0.6, alpha=0.5)
    ax.plot([0.08, 120], [0.16, 240], color=COLORS["MC"], lw=0.6, alpha=0.5)
    med = [float(r["median"]) / 1000 for _, r in pts]
    q1 = [float(r["q1"]) / 1000 for _, r in pts]
    q3 = [float(r["q3"]) / 1000 for _, r in pts]
    p99 = [float(r["p99"]) / 1000 for _, r in pts]
    ax.errorbar(s, med, yerr=[[m - a for m, a in zip(med, q1)], [b - m for m, b in zip(med, q3)]],
                marker="D", color=COLORS["MC"], capsize=2, lw=1, label="mediana (barras: quartis)")
    ax.plot(s, p99, "v", color=COLORS["MC"], mfc="none", label="p99")
    _log_ms_axis(ax)
    ax.set_yscale("log")
    ax.yaxis.set_major_formatter(PT)
    ax.yaxis.set_minor_formatter(NullFormatter())
    ax.set_xticks([0.1, 0.3, 1, 3, 10, 30, 100])
    ax.set_yticks([0.3, 1, 3, 10, 30, 100, 200])
    ax.set_xlim(0.08, 120)
    ax.set_ylim(0.3, 240)
    ax.set_xlabel("trecho sem ceder $S$ (ms)")
    ax.set_ylabel("latência no MC (ms)")
    ax.legend(loc="upper left")
    fig.savefig(out / "c_mc_faixa.pdf")
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--results", type=Path, default=Path("data/results/zbook"))
    ap.add_argument("--out", type=Path, default=Path("data/results/zbook/figuras"))
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    for fig in (fig_a_ram, fig_b_latency, fig_c_response, fig_c_mc_band):
        fig(args.results, args.out)
        print(f"{fig.__name__} ok")


if __name__ == "__main__":
    main()
