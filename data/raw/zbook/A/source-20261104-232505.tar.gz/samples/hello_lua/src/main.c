/**
 * @file main.c
 * @brief As threads Lua são criadas pelo lua_zephyr; main só se anuncia.
 */

#include <zephyr/kernel.h>
#include <zephyr/version.h>

int main(void)
{
	printk("hello_lua: Zephyr %s\n", KERNEL_VERSION_STRING);
	return 0;
}
