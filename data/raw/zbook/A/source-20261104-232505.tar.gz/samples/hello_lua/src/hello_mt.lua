-- Modelo preemptivo: o script é uma thread do Zephyr com heap próprio.
local z = require("zephyr")

for i = 1, 3 do
	z.printk("MT: " .. i)
	z.msleep(100)
end
