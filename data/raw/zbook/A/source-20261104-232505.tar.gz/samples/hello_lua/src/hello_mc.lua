-- Modelo cooperativo: tarefas como co-rotinas de um único interpretador.
local z = require("zephyr")
local async = require("zephyr.async")

local function worker(name)
	for i = 1, 3 do
		z.printk("MC " .. name .. ": " .. i)
		async.sleep(100)
	end
end

local a = async.spawn(worker, "a")
local b = async.spawn(worker, "b")
a:join()
b:join()
