/**
 * @file main.c
 * @brief Hello world: imprime uma mensagem por segundo no console serial.
 */

#include <zephyr/kernel.h>

int main(void)
{
	uint32_t n = 0;

	while (true) {
		printk("Hello world! %s (%u)\n", CONFIG_BOARD_TARGET, n++);
		k_sleep(K_SECONDS(1));
	}

	return 0;
}
