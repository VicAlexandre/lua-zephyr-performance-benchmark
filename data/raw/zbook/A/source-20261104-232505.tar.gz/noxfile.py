"""Tarefas de compilação, gravação e execução dos experimentos.

As sessões usam o ambiente já ativado pelo direnv (west, CMake e Zephyr SDK),
por isso não criam virtualenvs próprios.

Uso geral:
    nox -s build -- samples/hello_lua            # compila para a Zbook
    nox -s build -- app -DBENCH_EXP=B -DBENCH_MODEL=MC
    nox -s flash -- samples/hello_lua            # grava a última compilação
    nox -s monitor [-- /dev/ttyACM1]             # console serial
    nox -s clean                                 # remove build/

Experimentos (Metodologia), com opções após `--`:
    nox -s calibrate                  # bytes por posição de tabela -> app/calibration.conf
    nox -s exp_a                      # footprint
    nox -s exp_b                      # latência de despacho
    nox -s exp_c                      # bloqueio cooperativo
    nox -s bateria -- --detach        # A, B e C em sequência, sem supervisão (tmux)
    nox -s status                     # progresso da coleta e tempo restante
    nox -s stacks                     # ocupação máxima das pilhas (compilação à parte)
    nox -s analyze [-- qemu]          # estatísticas em data/results/<alvo>
    opções: --target zbook|qemu  --runs 10  --port /dev/ttyACM0  --only <regex>
            --quick (ensaio com poucas amostras)  --fresh (refaz tudo)  --allow-dirty

Os resultados brutos vão para data/raw/<alvo>/<experimento>/<configuração>/,
com o commit do firmware e o manifesto congelado em PROVENANCE.txt. Uma sessão
interrompida pode ser repetida: as execuções já gravadas e válidas são puladas.
"""

import argparse
import os
import shlex
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import nox

nox.options.default_venv_backend = "none"
nox.options.sessions = ["build"]

ROOT = Path(__file__).parent
APP = ROOT / "app"
DATA_ROOT = ROOT / "data" / "raw"
BOARDS = {"zbook": "zbook/rp2350b/m33", "qemu": "mps2/an385"}
DEFAULT_APP = "samples/hello_lua"

# Níveis dos fatores (Seção de Experimentos da Metodologia)
A_LEVELS = ["1", "2", "4", "8", "16", "31", "FULL"]
B_PAYLOADS = [1, 16, 64, 256, 1024]
C_SLICES_US = [100, 300, 1_000, 3_000, 10_000, 30_000, 50_000, 100_000]

# Dimensionamento dos heaps (Seção de Modelos da Metodologia): uma execução
# de sondagem com heap folgado, depois o pico observado mais 40 %.
HEAP_MARGIN = 1.40
PROBE_HEAP_MAX = 131_072
PROBE_BUDGET_MT = 393_216


# Sessões gerais
def _app_and_extra(session: nox.Session) -> tuple[Path, list[str]]:
    """Separa o caminho da aplicação dos argumentos extras de CMake."""
    args = list(session.posargs)
    app = Path(args.pop(0)) if args and not args[0].startswith("-") else Path(DEFAULT_APP)
    if not (ROOT / app / "CMakeLists.txt").exists():
        session.error(f"aplicação não encontrada: {app}")
    return app, args


def _build_dir(app: Path) -> Path:
    return ROOT / "build" / app.name


@nox.session
def build(session: nox.Session) -> None:
    """Compila uma aplicação para a Zbook."""
    app, extra = _app_and_extra(session)
    cmd = ["west", "build", "-p", "auto", "-b", BOARDS["zbook"],
           "-d", str(_build_dir(app)), str(ROOT / app)]
    if extra:
        cmd += ["--", *extra]
    session.run(*cmd, external=True)


@nox.session
def flash(session: nox.Session) -> None:
    """Grava a última compilação da aplicação pelo RP2040 (OpenOCD/CMSIS-DAP)."""
    app, _ = _app_and_extra(session)
    build_dir = _build_dir(app)
    if not build_dir.exists():
        session.error(f"{build_dir} não existe; rode antes: nox -s build -- {app}")
    import sys
    sys.path.insert(0, str(ROOT / "scripts"))
    from capture import west_flash_cmd

    session.run(*west_flash_cmd(build_dir), external=True)


@nox.session
def monitor(session: nox.Session) -> None:
    """Abre o console serial da Zbook (padrão /dev/ttyACM0, 115200 baud; Ctrl+] sai)."""
    port = session.posargs[0] if session.posargs else "/dev/ttyACM0"
    session.run("python", "-m", "serial.tools.miniterm", "--raw", port, "115200",
                external=True)


@nox.session
def clean(session: nox.Session) -> None:
    """Remove todos os diretórios de compilação."""
    shutil.rmtree(ROOT / "build", ignore_errors=True)


# Infraestrutura dos experimentos
@dataclass
class Config:
    name: str
    args: dict[str, str] = field(default_factory=dict)

    def cmake_args(self) -> list[str]:
        return [f"-D{k}={v}" for k, v in self.args.items()]


# Modo rápido: ensaio da orquestração com poucas amostras, em diretório próprio.
QUICK_ARGS = {"CONFIG_BENCH_WARMUP": "10", "CONFIG_BENCH_SAMPLES": "50",
              "CONFIG_BENCH_RUN_MS": "3000"}


def _options(session: nox.Session) -> argparse.Namespace:
    ap = argparse.ArgumentParser(prog=f"nox -s {session.name} --")
    ap.add_argument("--target", choices=BOARDS, default="zbook")
    ap.add_argument("--runs", type=int, default=10)
    ap.add_argument("--port", default="/dev/ttyACM0")
    ap.add_argument("--only", default="", help="só as configurações cujo nome casa com esta regex")
    ap.add_argument("--timeout", type=float, default=3600)
    ap.add_argument("--quick", action="store_true",
                    help="ensaio com poucas amostras, em data/raw/<alvo>-quick")
    ap.add_argument("--fresh", action="store_true",
                    help="refaz tudo, ignorando execuções e dimensionamentos já gravados")
    ap.add_argument("--allow-dirty", action="store_true",
                    help="permite coletar na Zbook com alterações não commitadas")
    ap.add_argument("--exps", default="A,B,C",
                    help="bateria: experimentos, em ordem (padrão A,B,C)")
    ap.add_argument("--detach", action="store_true",
                    help="bateria: roda em segundo plano, numa sessão tmux 'bateria'")
    return ap.parse_args(session.posargs)


def _data(opts: argparse.Namespace) -> Path:
    """Dados brutos separados por alvo, para não misturar QEMU, Zbook e ensaios."""
    return DATA_ROOT / (opts.target + ("-quick" if opts.quick else ""))


def _cfg_build_dir(opts: argparse.Namespace, cfg: Config) -> Path:
    return ROOT / "build" / opts.target / cfg.name


def _git(*args: str, cwd: Path = ROOT) -> str:
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True).stdout.strip()


def _provenance(session: nox.Session, opts: argparse.Namespace, exp: str) -> None:
    """Registra junto dos dados o commit do firmware e o manifesto congelado.
    Na Zbook, recusa coletar com alterações não commitadas."""
    dirty = _git("status", "--porcelain")
    if opts.target == "zbook" and not opts.quick and dirty and not opts.allow_dirty:
        session.error("há alterações não commitadas em tcc-experimentos; faça o commit antes "
                      "de coletar (ou use --allow-dirty)")
    frozen = subprocess.run(["west", "manifest", "--freeze"], cwd=ROOT,
                            capture_output=True, text=True).stdout
    out = _data(opts) / exp / "PROVENANCE.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    if dirty or not _git("rev-parse", "--verify", "HEAD"):
        # Sem commit que identifique o código: guarda uma cópia do código-fonte
        # (arquivos que o git veria, respeitando o .gitignore).
        files = _git("ls-files", "--cached", "--others", "--exclude-standard").split("\n")
        files = [f for f in files if f and not f.startswith("data/")]
        snap = out.parent / f"source-{stamp}.tar.gz"
        subprocess.run(["tar", "czf", str(snap), "-C", str(ROOT), *files], check=True)
    with out.open("a") as f:
        f.write(f"# sessão {session.name} em {datetime.now().isoformat(timespec='seconds')}\n"
                f"tcc-experimentos {_git('rev-parse', '--verify', 'HEAD') or 'sem commit'}"
                f"{' (com alterações não commitadas; código em source-' + stamp + '.tar.gz)' if dirty else ''}\n"
                f"opções {vars(opts)}\n{frozen}\n")


def _build_cfg(session: nox.Session, opts: argparse.Namespace, cfg: Config,
               check: bool = True) -> str | None:
    """Compila a configuração; devolve o log, ou None se falhar sem check."""
    args = cfg.cmake_args() + ([f"-D{k}={v}" for k, v in QUICK_ARGS.items()] if opts.quick else [])
    cmd = ["west", "build", "-p", "always", "-b", BOARDS[opts.target],
           "-d", str(_cfg_build_dir(opts, cfg)), str(APP), "--", *args]
    session.log(f"compilando {cfg.name}")
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        if check:
            session.error(f"falha ao compilar {cfg.name}:\n{proc.stdout[-3000:]}{proc.stderr[-3000:]}")
        return None
    return proc.stdout


def _validate(text: str) -> list[str]:
    """Problemas que invalidam uma execução; lista vazia se ela é válida."""
    problems = []
    if "Lua error" in text:
        problems.append("erro Lua durante a execução")
    m = re.search(r"#GEN pub_errors=(\d+)", text)
    if m is None:
        problems.append("sem linha #GEN")
    elif int(m.group(1)) > 0:
        problems.append(f"{m.group(1)} publicações falharam")
    fails = sum(int(x) for x in re.findall(r"#HEAP .*alloc_fail=(\d+)", text))
    if fails:
        problems.append(f"{fails} falhas de alocação")
    rows = re.findall(r"^\d+,(\d+),(\d+),(\d+)", text, re.M)
    empty = sum(1 for t0, t1, t2 in rows if "0" in (t0, t1, t2))
    if empty:
        problems.append(f"{empty} amostras sem algum dos carimbos t0, t1 ou t2")
    return problems


def _done(opts: argparse.Namespace, out: Path) -> bool:
    """Execução já gravada e válida (retomada), a menos de --fresh."""
    return not opts.fresh and out.exists() and not _validate(out.read_text())


def _capture(session: nox.Session, opts: argparse.Namespace, cfg: Config, out: Path,
             strict: bool = True) -> tuple[Path, list[str]]:
    """Executa e valida. Com strict, uma execução inválida interrompe a sessão;
    sem strict, os problemas são devolvidos para quem chamou decidir."""
    session.log(f"executando {cfg.name} -> {out.relative_to(ROOT)}")
    session.run("python", str(ROOT / "scripts" / "capture.py"),
                str(_cfg_build_dir(opts, cfg)), str(out), "--target", opts.target,
                "--port", opts.port, "--timeout", str(opts.timeout), external=True)
    problems = _validate(out.read_text())
    if problems:
        bad = out.with_suffix(".invalid.txt")
        out.replace(bad)
        if strict:
            session.error(f"{cfg.name}: execução inválida ({'; '.join(problems)}); "
                          f"saída mantida em {bad.relative_to(ROOT)}")
        return bad, problems
    return out, []


def _run_path(opts: argparse.Namespace, exp: str, cfg: Config, run: int) -> Path:
    return _data(opts) / exp / cfg.name / f"run_{run:02d}.txt"


def _run_interleaved(session: nox.Session, opts: argparse.Namespace, exp: str,
                     groups: list[list[Config]]) -> None:
    """Executa cada grupo (um nível do fator, um item por modelo) intercalando
    os modelos a cada repetição. Execuções já gravadas e válidas são puladas."""
    _provenance(session, opts, exp)
    for group in groups:
        group = [c for c in group if re.search(opts.only, c.name)]
        pending = [c for c in group
                   if not all(_done(opts, _run_path(opts, exp, c, r))
                              for r in range(1, opts.runs + 1))]
        if not pending:
            continue
        sized = []
        for cfg in group:
            res = _size_heaps(session, opts, cfg, _data(opts) / exp)
            if res is None:
                session.error(f"{cfg.name}: não coube na RAM")
            sized.append(res[0])
        for run in range(1, opts.runs + 1):
            for cfg in sized:
                out = _run_path(opts, exp, cfg, run)
                if not _done(opts, out):
                    _capture(session, opts, cfg, out)


def _heap_lines(path: Path) -> list[dict[str, str]]:
    heaps = []
    for line in path.read_text().splitlines():
        if line.startswith("#HEAP"):
            heaps.append(dict(kv.split("=", 1) for kv in line.split()[1:]))
    return heaps


def _footprint(build_log: str, build_dir: Path) -> dict[str, int]:
    fp = {"flash_bin": (build_dir / "zephyr" / "zephyr.bin").stat().st_size}
    for region, used, unit in re.findall(r"^\s*(FLASH|RAM):\s+(\d+)\s+(B|KB)", build_log, re.M):
        fp[f"{region.lower()}_used"] = int(used) * (1024 if unit == "KB" else 1)
    return fp


def _lua_threads(cfg: Config) -> int:
    """Número de threads Lua (estados) da configuração."""
    model, exp = cfg.args.get("BENCH_MODEL"), cfg.args.get("BENCH_EXP")
    if model == "MC":
        return 1
    if model != "MT":
        return 0
    if exp == "A":
        n = cfg.args.get("BENCH_N", "1")
        return 6 if n == "FULL" else int(n)
    return 2 if exp == "C" else 1


def _probe_heap(cfg: Config) -> int:
    return min(PROBE_HEAP_MAX, PROBE_BUDGET_MT // _lua_threads(cfg) // 256 * 256)


def _size_heaps(session: nox.Session, opts: argparse.Namespace, cfg: Config,
                exp_dir: Path) -> tuple[Config, str] | None:
    """Sonda o pico de cada heap Lua com folga e devolve a configuração com
    heaps de pico + 40 % já compilada, e o log da compilação. Reaproveita um
    dimensionamento já gravado (heaps.txt). Devolve None se a configuração não
    couber na RAM, inclusive quando o heap de sondagem, limitado pela RAM
    disponível, não basta para as tarefas (Experimento A)."""
    if _lua_threads(cfg) == 0:
        log = _build_cfg(session, opts, cfg, check=False)
        return (cfg, log) if log is not None else None

    heaps_file = exp_dir / cfg.name / "heaps.txt"
    if heaps_file.exists() and not opts.fresh:
        sized = {**cfg.args, **dict(l.split("=", 1) for l in heaps_file.read_text().split())}
    else:
        probe = Config(cfg.name, {**cfg.args, "BENCH_HEAP": str(_probe_heap(cfg))})
        if _build_cfg(session, opts, probe, check=False) is None:
            return None
        out, problems = _capture(session, opts, probe, exp_dir / cfg.name / "probe.txt",
                                 strict=False)
        if problems:
            if cfg.args.get("BENCH_EXP") == "A":
                session.log(f"{cfg.name}: heap de sondagem insuficiente "
                            f"({'; '.join(problems)}); não coube na RAM")
                return None
            session.error(f"{cfg.name}: sondagem inválida ({'; '.join(problems)})")
        sized = dict(cfg.args)
        for h in _heap_lines(out):
            size = int(int(h["peak"]) * HEAP_MARGIN + 7) // 8 * 8
            key = "BENCH_HEAP" if cfg.args["BENCH_MODEL"] == "MC" else f"BENCH_HEAP_{h['name']}"
            sized[key] = str(size)

    final = Config(cfg.name, sized)
    log = _build_cfg(session, opts, final, check=False)
    if log is None:
        return None
    heaps_file.write_text(
        "".join(f"{k}={v}\n" for k, v in sized.items() if k.startswith("BENCH_HEAP")))
    return final, log


def _configs_a() -> list[Config]:
    cfgs = [Config("A_NONE", {"BENCH_EXP": "A", "BENCH_MODEL": "NONE"})]
    for level in A_LEVELS:
        for model in ("MT", "MC"):
            cfgs.append(Config(f"A_{model}_n{level}",
                               {"BENCH_EXP": "A", "BENCH_MODEL": model, "BENCH_N": level}))
    return cfgs


def _groups_b() -> list[list[Config]]:
    return [[Config(f"B_{m}_p{p}", {"BENCH_EXP": "B", "BENCH_MODEL": m,
                                    "BENCH_PAYLOAD": str(p)})
             for m in ("MT", "MC", "BASE")]
            for p in B_PAYLOADS]


def _groups_c() -> list[list[Config]]:
    return [[Config(f"C_MC_s{s}", {"BENCH_EXP": "C", "BENCH_MODEL": "MC",
                                   "BENCH_SLICE_US": str(s)}),
             Config(f"C_MTEQ_s{s}", {"BENCH_EXP": "C", "BENCH_MODEL": "MT",
                                     "BENCH_SLICE_US": str(s), "BENCH_PRIO": "EQUAL"}),
             Config(f"C_MTSPLIT_s{s}", {"BENCH_EXP": "C", "BENCH_MODEL": "MT",
                                        "BENCH_SLICE_US": str(s), "BENCH_PRIO": "SPLIT"})]
            for s in C_SLICES_US]


# Experimentos
@nox.session
def calibrate(session: nox.Session) -> None:
    """Mede o tamanho de posição de tabela e o custo da sonda; grava app/calibration.conf."""
    opts = _options(session)
    cfg = Config("CAL", {"BENCH_EXP": "CAL"})
    _build_cfg(session, opts, cfg)
    out, _ = _capture(session, opts, cfg, _data(opts) / "CAL" / "cal.txt")

    text = out.read_text()
    slots, nbytes = re.search(r"#CAL table slots=(\d+) bytes=([\d.]+)", text).groups()
    slot_bytes = max(1, round(float(nbytes) / int(slots)))

    session.log(f"SLOT_BYTES={slot_bytes}")
    if opts.target != "zbook":
        session.log("alvo diferente da Zbook: app/calibration.conf não foi alterado")
        return
    (APP / "calibration.conf").write_text(
        "# Constantes da calibração na Zbook (nox -s calibrate); ver data/raw/zbook/CAL/cal.txt.\n"
        f"CONFIG_BENCH_SLOT_BYTES={slot_bytes}\n")


def _exp_a(session: nox.Session, opts: argparse.Namespace) -> None:
    exp_dir = _data(opts) / "A"
    _provenance(session, opts, "A")

    for cfg in _configs_a():
        if not re.search(opts.only, cfg.name):
            continue
        cfg_dir = exp_dir / cfg.name
        cfg_dir.mkdir(parents=True, exist_ok=True)
        if cfg.args["BENCH_MODEL"] == "NONE":
            # Referência: parte fixa do sistema, sem tarefas Lua; só compilação.
            log = _build_cfg(session, opts, cfg)
            (cfg_dir / "footprint.txt").write_text(
                "".join(f"{k}={v}\n" for k, v in _footprint(log, _cfg_build_dir(opts, cfg)).items()))
            continue
        runs = [cfg_dir / f"run_{r:02d}.txt" for r in range(1, opts.runs + 1)]
        if (cfg_dir / "footprint.txt").exists() and all(_done(opts, r) for r in runs):
            continue
        res = _size_heaps(session, opts, cfg, exp_dir)
        if res is None:
            session.log(f"{cfg.name}: não coube na RAM")
            (cfg_dir / "footprint.txt").write_text("fits=0\n")
            continue
        sized, log = res
        (cfg_dir / "footprint.txt").write_text(
            "fits=1\n" + "".join(f"{k}={v}\n" for k, v in
                                 _footprint(log, _cfg_build_dir(opts, sized)).items()))
        for out in runs:
            if not _done(opts, out):
                _capture(session, opts, sized, out)


@nox.session
def exp_a(session: nox.Session) -> None:
    """Experimento A: footprint de Flash e RAM em função de N."""
    _exp_a(session, _options(session))


@nox.session
def exp_b(session: nox.Session) -> None:
    """Experimento B: latência de despacho por payload (MT, MC e baseline)."""
    _run_interleaved(session, _options(session), "B", _groups_b())


@nox.session
def exp_c(session: nox.Session) -> None:
    """Experimento C: tempo de resposta da T4 sob a tarefa de fundo T2."""
    _run_interleaved(session, _options(session), "C", _groups_c())


@nox.session
def bateria(session: nox.Session) -> None:
    """Bateria de experimentos (A, B e C em sequência), sem supervisão.

    Impede a suspensão do computador (systemd-inhibit) e grava toda a saída em
    data/raw/<alvo>/bateria.log. Com --detach, roda numa sessão tmux 'bateria'
    (acompanhe com `tmux attach -t bateria`; saia com Ctrl+b d). Interrompida,
    basta repetir o comando: as execuções já gravadas e válidas são puladas.
    """
    opts = _options(session)
    exps = [e.strip().upper() for e in opts.exps.split(",") if e.strip()]
    if any(e not in ("A", "B", "C") for e in exps):
        session.error(f"--exps aceita A, B e C; recebido {opts.exps}")
    args = [a for a in session.posargs if a != "--detach"]
    log = _data(opts) / "bateria.log"
    log.parent.mkdir(parents=True, exist_ok=True)

    if opts.detach:
        if shutil.which("tmux") is None:
            session.error("tmux não encontrado")
        if subprocess.run(["tmux", "has-session", "-t", "bateria"],
                          capture_output=True).returncode == 0:
            session.error("já existe uma sessão tmux 'bateria' (tmux attach -t bateria)")
        cmd = f"cd {shlex.quote(str(ROOT))} && direnv exec . nox -s bateria -- {shlex.join(args)}"
        subprocess.run(["tmux", "new-session", "-d", "-s", "bateria", cmd], check=True)
        session.log(f"bateria iniciada na sessão tmux 'bateria'; log em {log.relative_to(ROOT)}")
        session.log("acompanhar: tmux attach -t bateria   |   sair sem interromper: Ctrl+b d")
        return

    # Reexecuta sob systemd-inhibit, com a saída duplicada no log.
    if os.environ.get("TCC_BATERIA") is None:
        inner = f"set -o pipefail; nox -s bateria -- {shlex.join(args)} 2>&1 | tee -a {shlex.quote(str(log))}"
        cmd = ["bash", "-c", inner]
        if shutil.which("systemd-inhibit"):
            cmd = ["systemd-inhibit", "--what=sleep:idle", "--who=tcc-experimentos",
                   "--why=bateria de experimentos", *cmd]
        else:
            session.warn("systemd-inhibit não encontrado: o computador pode suspender")
        session.run(*cmd, external=True, env={"TCC_BATERIA": "1"})
        return

    session.log(f"bateria: {', '.join(exps)} em {opts.target} ({datetime.now():%Y-%m-%d %H:%M})")
    for exp in exps:
        session.log(f"=== Experimento {exp} ===")
        if exp == "A":
            _exp_a(session, opts)
        elif exp == "B":
            _run_interleaved(session, opts, "B", _groups_b())
        else:
            _run_interleaved(session, opts, "C", _groups_c())
    session.log(f"bateria concluída ({datetime.now():%Y-%m-%d %H:%M})")


@nox.session
def analyze(session: nox.Session) -> None:
    """Análise estatística: data/raw/<alvo> -> data/results/<alvo> (alvo: zbook ou qemu)."""
    args = list(session.posargs)
    target = args.pop(0) if args and not args[0].startswith("-") else "zbook"
    session.run("python", str(ROOT / "analysis" / "analyze.py"),
                "--raw", str(DATA_ROOT / target), "--out", str(ROOT / "data" / "results" / target),
                *args, external=True)


@nox.session
def stacks(session: nox.Session) -> None:
    """Ocupação máxima das pilhas em todas as configurações (compilação à parte)."""
    opts = _options(session)
    cfgs = _configs_a() + [c for g in _groups_b() + _groups_c() for c in g]
    out_dir = _data(opts) / "STACK"
    rows = []
    for cfg in cfgs:
        if not re.search(opts.only, cfg.name):
            continue
        args = {**cfg.args, "BENCH_DIAG": "STACK",
                # Execução curta: a ocupação da pilha não depende do número de amostras.
                "CONFIG_BENCH_WARMUP": "10", "CONFIG_BENCH_SAMPLES": "100"}
        if _lua_threads(cfg):
            args["BENCH_HEAP"] = str(_probe_heap(cfg))
        diag = Config(cfg.name, args)
        out = out_dir / f"{cfg.name}.txt"
        if not _done(opts, out):
            if _build_cfg(session, opts, diag, check=False) is None:
                session.log(f"{cfg.name}: não coube na RAM; pilhas não verificadas")
                continue
            out, problems = _capture(session, opts, diag, out, strict=False)
            if problems:
                session.log(f"{cfg.name}: execução inválida ({'; '.join(problems)}); "
                            "pilhas não verificadas")
                continue
        text = out.read_text()
        for line in text.splitlines():
            if line.startswith("#STACK"):
                kv = dict(x.split("=", 1) for x in line.split()[1:])
                used, size = int(kv["used"]), int(kv["size"])
                rows.append((cfg.name, kv["name"], size, used, used / size if size else 0.0))

    summary = DATA_ROOT.parent / "results" / opts.target / "stacks.csv"
    summary.parent.mkdir(parents=True, exist_ok=True)
    with summary.open("w") as f:
        f.write("config,thread,size,used,ratio\n")
        for r in rows:
            f.write(f"{r[0]},{r[1]},{r[2]},{r[3]},{r[4]:.3f}\n")
    worst = sorted(rows, key=lambda r: r[4], reverse=True)[:10]
    for r in worst:
        session.log(f"{r[0]:>16} {r[1]:<28} {r[3]:>6}/{r[2]:<6} {r[4]:.0%}")
    if any(r[4] >= 0.9 for r in rows):
        session.error("alguma pilha passou de 90 % de ocupação")


def _run_seconds(cfg: Config, quick: bool) -> float:
    """Duração estimada de uma execução (coleta, gravação, boot e emissão)."""
    n = 60 if quick else 1100  # aquecimento + amostras
    exp = cfg.args.get("BENCH_EXP")
    if exp == "A":
        return (3 if quick else 10) + 1 + 6
    if exp == "B":
        return n * 0.015 + 1 + 8  # intervalo uniforme em [10, 20) ms
    s = int(cfg.args["BENCH_SLICE_US"]) / 1e6
    m = max(2.5 * s, 0.020)  # intervalo mínimo da T4
    return n * 1.5 * m + max(1.0, 3 * s) + 8


@nox.session
def status(session: nox.Session) -> None:
    """Progresso da coleta: execuções prontas, inválidas e pendentes, com estimativa.

    Só lê os arquivos em data/raw; pode ser chamada a qualquer momento, inclusive
    com a bateria rodando. Aceita --target, --runs e --quick.
    """
    opts = _options(session)
    data = _data(opts)
    exps = {"A": [c for c in _configs_a() if c.args["BENCH_MODEL"] != "NONE"],
            "B": [c for g in _groups_b() for c in g],
            "C": [c for g in _groups_c() for c in g]}
    total_left = 0.0
    lines = [f"{'exp':<4}{'prontas':>9}{'inválidas':>11}{'pendentes':>11}"
             f"{'não coube':>11}{'restante':>11}"]
    newest = None
    for exp, cfgs in exps.items():
        done = bad = pend = nofit = 0
        left = 0.0
        for cfg in cfgs:
            d = data / exp / cfg.name
            if (d / "footprint.txt").exists() and "fits=0" in (d / "footprint.txt").read_text():
                nofit += 1
                continue
            bad += len(list(d.glob("*.invalid.txt"))) if d.exists() else 0
            probe_left = _lua_threads(cfg) > 0 and not (d / "heaps.txt").exists()
            missing = 0
            for r in range(1, opts.runs + 1):
                out = d / f"run_{r:02d}.txt"
                if out.exists() and not _validate(out.read_text()):
                    done += 1
                    mt = out.stat().st_mtime
                    newest = mt if newest is None or mt > newest else newest
                else:
                    missing += 1
            pend += missing
            left += (missing + probe_left) * _run_seconds(cfg, opts.quick)
        total_left += left
        lines.append(f"{exp:<4}{done:>9}{bad:>11}{pend:>11}{nofit:>11}"
                     f"{left / 3600:>9.1f} h")
    for line in lines:
        session.log(line)
    session.log(f"tempo restante estimado: {total_left / 3600:.1f} h")
    if newest is not None:
        session.log(f"última execução gravada: {datetime.fromtimestamp(newest):%Y-%m-%d %H:%M:%S}")
    alive = shutil.which("tmux") and subprocess.run(
        ["tmux", "has-session", "-t", "bateria"], capture_output=True).returncode == 0
    session.log(f"sessão tmux 'bateria': {'ativa' if alive else 'inexistente'}")
