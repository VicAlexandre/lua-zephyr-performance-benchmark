# tcc-experimentos

Experimentos do TCC *Lua e Zephyr: análise de modelos de concorrência*:
comparação dos modelos preemptivo (MT) e cooperativo (MC) do `lua_zephyr`
na Zbook (RP2350B, Cortex-M33).

Este repositório é o manifesto de um workspace west em topologia T2: as
aplicações ficam aqui, e o Zephyr e os módulos são clonados ao lado.

```
tcc-ws/
├── tcc-experimentos/   # este repositório (manifesto e aplicações)
├── zephyr/             # v4.5.0
└── modules/
    ├── lang/lua_zephyr # feat/async-coroutine-scheduler
    ├── boards/zbook    # definição da placa
    └── hal/            # cmsis_6, rpi_pico
```

As revisões estão fixadas por commit em `west.yml`.

## Requisitos

- [uv](https://docs.astral.sh/uv/) e [direnv](https://direnv.net/) (com o
  hook do shell configurado)
- Zephyr SDK 1.0.0. O caminho padrão é `~/zephyr-sdk-1.0.0`; outro caminho vai
  em `.envrc.local`:
  `export ZEPHYR_SDK_INSTALL_DIR=/caminho/do/sdk`
- OpenOCD com suporte a RP2350, para gravar pela sonda RP2040 da Zbook. O do
  Zephyr SDK não tem `target/rp2350.cfg`; o `.envrc` aponta para
  `/usr/local/bin/openocd` (variáveis `OPENOCD` e `OPENOCD_SCRIPTS`,
  sobrescrevíveis em `.envrc.local`)

## Preparação do workspace

```sh
mkdir tcc-ws && cd tcc-ws
git clone <url-deste-repositório> tcc-experimentos
cd tcc-experimentos
direnv allow          # cria .venv com uv (west, nox, dependências do Zephyr)
west init -l .
west update --narrow -o=--depth=1
```

Ao entrar em `tcc-experimentos/`, o direnv ativa o ambiente: Python 3.12 do
`uv.lock`, `west`, `nox` e as variáveis do Zephyr SDK.

## Compilação e gravação

As tarefas são sessões do nox (`noxfile.py`):

```sh
nox -s build -- samples/hello_lua              # compila para zbook/rp2350b/m33
nox -s build -- samples/hello_lua -DCONFIG_X=y # argumentos extras para o CMake
nox -s flash -- samples/hello_lua              # grava a última compilação
nox -s clean                                   # remove build/
nox -l                                         # lista as sessões
```

Cada aplicação compila em `build/<nome-da-aplicação>/`.

## Aplicações

| Caminho | Descrição |
|---|---|
| `app` | Aplicação dos experimentos (calibração, A, B e C) |
| `samples/xip_check` | Custo de uma publicação no zbus e falhas na cache XIP (contadores CTR_HIT/CTR_ACC do RP2350) |
| `samples/dwt_check` | Validação do console serial e do contador DWT CYCCNT (frequência e custo da leitura) |
| `samples/hello_world` | Hello world em C, sem Lua: valida placa, gravação e console serial |
| `samples/hello_lua` | Validação do ambiente: uma thread Lua preemptiva e uma thread assíncrona com duas tarefas |

## Experimentos

A aplicação `app/` implementa a Metodologia. Cada configuração é escolhida por
variáveis CMake (`BENCH_EXP`, `BENCH_MODEL`, `BENCH_N`, `BENCH_PAYLOAD`,
`BENCH_SLICE_US`, `BENCH_PRIO`, `BENCH_HEAP`; ver `app/CMakeLists.txt`), e
`app/cmake/bench.cmake` gera as threads Lua de cada modelo:

- **MT**: um script de entrada por tarefa, cada um em uma thread com estado,
  heap e `message subscriber` próprios;
- **MC**: um script que cria uma tarefa assíncrona por arquétipo em uma única
  thread;
- **BASE**: receptor em C da T4, sem Lua (Experimento B);
- **NONE**: sem tarefas, referência da parte fixa do footprint.

O corpo dos arquétipos está em `app/lua/tasks.lua`, compartilhado pelos dois
modelos. O gerador de estímulos (`app/src/stimulus.c`), a sonda de ciclos
(`app/src/probe.c`, DWT CYCCNT) e a biblioteca Lua `bench`
(`app/src/lua_bench.c`) são comuns a todas as configurações.

Fluxo completo na Zbook:

```sh
nox -s calibrate     # grava app/calibration.conf (bytes por posição de tabela)
nox -s exp_a         # footprint: sondagem do heap, heap = pico + 40 %, 10 execuções
nox -s exp_b         # latência de despacho: MT, MC e baseline, payloads 1 a 1024 B
nox -s exp_c         # bloqueio cooperativo: MC, MT com prioridades iguais e MT com prioridade
nox -s analyze       # tabelas em data/results/zbook
```

Opções comuns após `--`: `--runs N`, `--only <regex>` (filtra configurações
pelo nome), `--port /dev/ttyACMx` e `--target qemu`.

Com `--target qemu`, tudo roda no `mps2/an385` emulado, com a sonda em
`k_cycle_get_32()`. Serve para validar o pipeline, e os dados ficam em
`data/raw/qemu`, fora do controle de versão.

### Formato da saída

Cada execução gera um arquivo com o cabeçalho `#BENCH` (parâmetros), o custo
das sondas (`#PROBE`), os contadores do gerador (`#GEN`), um `#HEAP` por estado
Lua (tamanho, pico e falhas de alocação) e, nos Experimentos B e C, a tabela
`seq,t0,t1,t2` em ciclos, terminada por `#END`.
