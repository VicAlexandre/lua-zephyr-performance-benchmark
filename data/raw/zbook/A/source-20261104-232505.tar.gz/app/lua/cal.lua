-- Calibração, executada antes dos experimentos (CONFIG_BENCH_EXP_CAL).
--
-- Mede, na própria placa:
--   * o custo da sonda em Lua (pares de leituras consecutivas);
--   * a memória ocupada por posição de tabela, de onde se obtém
--     CONFIG_BENCH_SLOT_BYTES.
--
-- O laço de trabalho não é calibrado: ele é temporizado pelo contador de
-- ciclos (lua/tasks.lua).

local z = require("zephyr")
local bench = require("bench")

for _ = 1, 16 do
	bench.tick() bench.tick()
end

local SLOTS = 1000
collectgarbage("collect")
collectgarbage("stop")
local m0 = collectgarbage("count")
local t = {}
for i = 1, SLOTS do
	t[i] = i
end
local m1 = collectgarbage("count")
collectgarbage("restart")
-- collectgarbage("count") devolve KB em ponto flutuante; "| 0" converte o
-- valor (inteiro em bytes) para inteiro, evitando printf de ponto flutuante.
local bytes = ((m1 - m0) * 1024) // 1 | 0
z.printk("#CAL table slots=" .. SLOTS .. " bytes=" .. bytes)

bench.dump()
