/**
 * @file bench.h
 * @brief Instrumentação dos experimentos: sonda de ciclos, registro de
 *        amostras, estatísticas de heap e sincronização de prontidão.
 */

#ifndef BENCH_H_
#define BENCH_H_

#include <stdint.h>
#include <zephyr/kernel.h>

#ifndef CONFIG_BENCH_PROBE_KCYCLE
#include <cmsis_core.h>
#endif

/** Pontos de medição (Seção de Instrumentação da Metodologia). */
enum bench_point {
	BENCH_T0 = 0, /**< gerador, imediatamente antes da publicação */
	BENCH_T1 = 1, /**< tarefa, após o retorno da primitiva de espera */
	BENCH_T2 = 2, /**< tarefa, ao término do corpo */
};

/** Total de ativações registradas da tarefa medida. */
#define BENCH_TOTAL (CONFIG_BENCH_WARMUP + CONFIG_BENCH_SAMPLES)

/** @brief Lê o contador de ciclos (DWT CYCCNT na Zbook). */
static ALWAYS_INLINE uint32_t bench_cycles(void)
{
#ifdef CONFIG_BENCH_PROBE_KCYCLE
	return k_cycle_get_32();
#else
	return DWT->CYCCNT;
#endif
}

/** @brief Frequência do contador, em Hz. */
uint32_t bench_hz(void);

/**
 * @brief Registra um carimbo já lido para a tarefa medida.
 *
 * Ignora tarefas que não são a medida (CONFIG_BENCH_MEASURED_TASK) e
 * sequências fora do buffer, de modo que todas as tarefas podem chamar a
 * sonda com o mesmo código.
 */
void bench_record(enum bench_point point, int task, uint32_t seq, uint32_t cycles);

/** @brief Registra um carimbo de calibração (pares de leituras consecutivas). */
void bench_tick(uint32_t cycles);

/** @brief Mediana dos pares de carimbos de calibração registrados. */
uint32_t bench_tick_median(void);

/** @brief Custo da sonda em C: mediana de leituras consecutivas. */
uint32_t bench_probe_cost_c(void);

/** @brief Espera ativa de @p us microssegundos pelo contador de ciclos. */
void bench_busy_us(uint32_t us);

/** @brief Sinaliza que uma tarefa está pronta para receber ativações. */
void bench_ready(void);

/** @brief Aguarda CONFIG_BENCH_NTASKS sinais de prontidão. */
int bench_wait_ready(k_timeout_t timeout);

/** @brief Emite o cabeçalho, as estatísticas de heap e as amostras. */
void bench_dump(void);

/** @brief Emite as estatísticas dos heaps Lua registrados. */
void bench_heap_dump(void);

/** @brief Diagnóstico: carimbo extra @p col (0 a 3) da ativação @p seq. */
void bench_diag(int col, int task, uint32_t seq, uint32_t cycles);

/** @brief Diagnóstico: marca o fim de um ciclo do coletor de lixo. */
void bench_gc_mark(uint32_t cycles);

/** @brief Emite os contadores do gerador de estímulos. */
void bench_gen_dump(void);

#endif /* BENCH_H_ */
