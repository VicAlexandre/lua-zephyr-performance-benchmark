# Geração das tarefas de cada configuração dos experimentos.
#
# A partir de BENCH_EXP e BENCH_MODEL, gera em ${BENCH_GEN_DIR}:
#   * bench.conf: fragmento Kconfig (experimento, modelo, arquétipos ativos,
#     heaps, prioridades e limites do escalonador assíncrono);
#   * os scripts Lua de entrada de cada thread (MT: um por tarefa; MC: um que
#     cria uma tarefa assíncrona por arquétipo);
#   * bench_glue.c: observadores do zbus das threads MT e ganchos de setup.
#
# Deve ser incluído antes de find_package(Zephyr), pois define as threads Lua
# e acrescenta o fragmento a EXTRA_CONF_FILE.

set(BENCH_GEN_DIR ${CMAKE_CURRENT_BINARY_DIR}/bench_gen)
file(MAKE_DIRECTORY ${BENCH_GEN_DIR})

# O luaz.cmake resolve os scripts em relação ao diretório da aplicação.
function(_bench_rel _path _out)
  file(RELATIVE_PATH _rel ${CMAKE_CURRENT_SOURCE_DIR} ${_path})
  set(${_out} ${_rel} PARENT_SCOPE)
endfunction()

set(_valid_models MT MC BASE NONE)
if(NOT BENCH_MODEL IN_LIST _valid_models)
  message(FATAL_ERROR "BENCH_MODEL deve ser um de: ${_valid_models}")
endif()

# Tarefas da configuração: lista de "arquétipo:id".
if(BENCH_EXP STREQUAL "CAL")
  set(BENCH_MODEL MT)
  set(_tasks "")
elseif(BENCH_EXP STREQUAL "A")
  if(BENCH_N STREQUAL "FULL")
    set(_tasks t1:1 t2:2 t3:3 t4:4 t5:5 t6:6)
  else()
    if(BENCH_N LESS 1 OR BENCH_N GREATER 31)
      message(FATAL_ERROR "BENCH_N deve estar entre 1 e 31, ou ser FULL")
    endif()
    set(_tasks "")
    foreach(_i RANGE 1 ${BENCH_N})
      list(APPEND _tasks t1:1)
    endforeach()
  endif()
elseif(BENCH_EXP STREQUAL "B")
  set(_tasks t4:4)
elseif(BENCH_EXP STREQUAL "C")
  set(_tasks t2bg:2 t4:4)
else()
  message(FATAL_ERROR "BENCH_EXP deve ser um de: CAL A B C")
endif()

if(BENCH_MODEL STREQUAL "NONE")
  set(_tasks "")
elseif(BENCH_MODEL STREQUAL "BASE")
  if(NOT BENCH_EXP STREQUAL "B")
    message(FATAL_ERROR "O baseline (BENCH_MODEL=BASE) só existe no Experimento B")
  endif()
  set(_tasks "")
endif()

list(LENGTH _tasks _ntasks)

# Fragmento Kconfig
set(_conf "# Gerado por cmake/bench.cmake; não editar.\n")
string(APPEND _conf "CONFIG_BENCH_EXP_${BENCH_EXP}=y\n")
string(APPEND _conf "CONFIG_BENCH_MODEL_${BENCH_MODEL}=y\n")
if(BENCH_MODEL STREQUAL "BASE")
  string(APPEND _conf "CONFIG_BENCH_NTASKS=1\n")
else()
  string(APPEND _conf "CONFIG_BENCH_NTASKS=${_ntasks}\n")
endif()

# Arquétipos ativados pelo gerador (a tarefa de fundo não recebe ativações).
set(_enabled "")
foreach(_t IN LISTS _tasks)
  string(REPLACE ":" ";" _p ${_t})
  list(GET _p 0 _arch)
  if(NOT _arch STREQUAL "t2bg")
    list(APPEND _enabled ${_arch})
  endif()
endforeach()
if(BENCH_MODEL STREQUAL "BASE")
  list(APPEND _enabled t4)
endif()
list(REMOVE_DUPLICATES _enabled)
foreach(_arch IN LISTS _enabled)
  string(TOUPPER ${_arch} _up)
  string(APPEND _conf "CONFIG_BENCH_${_up}_ENABLE=y\n")
endforeach()

if(BENCH_EXP STREQUAL "B")
  string(APPEND _conf "CONFIG_BENCH_T4_PERIOD_MS=10\n")
  string(APPEND _conf "CONFIG_BENCH_T4_P_BYTES=${BENCH_PAYLOAD}\n")
elseif(BENCH_EXP STREQUAL "C")
  # Intervalo mínimo da T4: 2,5 S, com piso de 20 ms. No MC, o atraso chega a
  # 2S (Seção 2.4.2); com 2,5 S, cada ativação é atendida antes da seguinte.
  math(EXPR _min_ms "(5 * ${BENCH_SLICE_US} + 1999) / 2000")
  if(_min_ms LESS 20)
    set(_min_ms 20)
  endif()
  string(APPEND _conf "CONFIG_BENCH_SLICE_US=${BENCH_SLICE_US}\n")
  string(APPEND _conf "CONFIG_BENCH_T4_PERIOD_MS=${_min_ms}\n")
endif()

if("COLS" IN_LIST BENCH_DIAG)
  string(APPEND _conf "CONFIG_BENCH_DIAG_COLS=y\n")
endif()
if("STACK" IN_LIST BENCH_DIAG)
  string(APPEND _conf "CONFIG_BENCH_DIAG_STACK=y\n")
endif()
if("GC" IN_LIST BENCH_DIAG)
  string(APPEND _conf "CONFIG_BENCH_DIAG_GC=y\n")
endif()

# Threads, scripts de entrada e código de ligação
set(_glue "/* Gerado por cmake/bench.cmake; não editar. */\n\n")
string(APPEND _glue "#include <lua.h>\n#include <zephyr/zbus/zbus.h>\n\n")
string(APPEND _glue "#include \"channels.h\"\n\n")
string(APPEND _glue "int bench_lua_setup(lua_State *L, const char *name);\n\n")

macro(_bench_setup_hook _name)
  string(APPEND _glue "int ${_name}_lua_setup(lua_State *L)\n{\n")
  string(APPEND _glue "\treturn bench_lua_setup(L, \"${_name}\");\n}\n\n")
endmacro()

if(BENCH_EXP STREQUAL "CAL")
  luaz_define_bytecode_thread(lua/cal.lua)
  _bench_setup_hook(cal)
  string(APPEND _conf "CONFIG_CAL_LUA_THREAD_HEAP_SIZE=${BENCH_HEAP}\n")

elseif(BENCH_MODEL STREQUAL "MT")
  set(_k 0)
  foreach(_t IN LISTS _tasks)
    string(REPLACE ":" ";" _p ${_t})
    list(GET _p 0 _arch)
    list(GET _p 1 _id)
    if(_k LESS 10)
      set(_name ${_arch}_0${_k})
    else()
      set(_name ${_arch}_${_k})
    endif()
    string(TOUPPER ${_name} _up)

    if(_arch STREQUAL "t2bg")
      set(_src "nil")
    else()
      set(_src "\"${_name}_sub\"")
      string(APPEND _glue "ZBUS_MSG_SUBSCRIBER_DEFINE(${_name}_sub);\n")
      string(APPEND _glue "ZBUS_CHAN_ADD_OBS(chan_${_arch}, ${_name}_sub, 3);\n\n")
    endif()

    file(WRITE ${BENCH_GEN_DIR}/${_name}.lua
      "-- Gerado por cmake/bench.cmake; não editar.\n"
      "require(\"tasks\").run(\"mt\", \"${_arch}\", ${_id}, ${_src})\n")
    _bench_rel(${BENCH_GEN_DIR}/${_name}.lua _rel)
    luaz_define_bytecode_thread(${_rel})
    _bench_setup_hook(${_name})
    # Heap por tarefa: BENCH_HEAP_<nome> sobrescreve BENCH_HEAP.
    if(DEFINED BENCH_HEAP_${_name})
      string(APPEND _conf "CONFIG_${_up}_LUA_THREAD_HEAP_SIZE=${BENCH_HEAP_${_name}}\n")
    else()
      string(APPEND _conf "CONFIG_${_up}_LUA_THREAD_HEAP_SIZE=${BENCH_HEAP}\n")
    endif()

    # Experimento C com prioridade: a tarefa de fundo abaixo da T4.
    if(_arch STREQUAL "t2bg" AND BENCH_PRIO STREQUAL "SPLIT")
      string(APPEND _conf "CONFIG_${_up}_LUA_THREAD_PRIORITY=8\n")
    endif()
    math(EXPR _k "${_k} + 1")
  endforeach()

elseif(BENCH_MODEL STREQUAL "MC")
  set(_lua "-- Gerado por cmake/bench.cmake; não editar.\n")
  string(APPEND _lua "local tasks = require(\"tasks\")\n")
  string(APPEND _lua "local async = require(\"zephyr.async\")\n")
  string(APPEND _lua "local h = {}\n")
  foreach(_t IN LISTS _tasks)
    string(REPLACE ":" ";" _p ${_t})
    list(GET _p 0 _arch)
    list(GET _p 1 _id)
    if(_arch STREQUAL "t2bg")
      set(_src "nil")
    else()
      set(_src "\"chan_${_arch}\"")
    endif()
    string(APPEND _lua
      "h[#h + 1] = async.spawn(tasks.run, \"mc\", \"${_arch}\", ${_id}, ${_src})\n")
  endforeach()
  string(APPEND _lua "for _, t in ipairs(h) do\n\tt:join()\nend\n")
  file(WRITE ${BENCH_GEN_DIR}/mc.lua "${_lua}")

  _bench_rel(${BENCH_GEN_DIR}/mc.lua _rel)
  luaz_define_async_thread(mc BYTECODE ${_rel})
  _bench_setup_hook(mc)
  math(EXPR _max_tasks "${_ntasks} + 1")
  string(APPEND _conf "CONFIG_LUA_ASYNC=y\n")
  string(APPEND _conf "CONFIG_LUA_ASYNC_MAX_TASKS=${_max_tasks}\n")
  string(APPEND _conf "CONFIG_MC_LUA_THREAD_HEAP_SIZE=${BENCH_HEAP}\n")
endif()

file(WRITE ${BENCH_GEN_DIR}/bench.conf "${_conf}")
file(WRITE ${BENCH_GEN_DIR}/bench_glue.c "${_glue}")
list(APPEND EXTRA_CONF_FILE ${BENCH_GEN_DIR}/bench.conf)
